# Laptop-Price-ML-Project

For more details about the project, check out my medium article here!

Link: https://lnkd.in/gikHvG7
